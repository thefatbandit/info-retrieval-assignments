Directory structure:

class1, class2: The folder name is itself the class label. Each of them contains the train-test split (around 75% for training and 25% for testing), under "train" and "test" folder respectively. 
